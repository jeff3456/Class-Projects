/*Author: Jefferson Lee
 * Date: 4/5/2014
 * Section: CS101, Section 03, Spring 2014
 */
public class Location 
{
	public int row;
	public int column;
	public int value;
	public Location(int row, int column, int value)
	{
		this.row = row;
		this.column = column;
		this.value = value;
	}
}
