/* Author: Jefferson Lee
 * Date: 01/29/2014
 * Section: CS101, Section 03, Spring 2014
 */
public class Assignment01c 
{
	public static void main(String[] args)
	{
		double width = 3.6;
		double height = 4.9;
		double area = width * height;
		double perimeter = 2 * width + 2 * height;
		System.out.println("Given a rectangle of width "+ width + " and " + height + "...");
		System.out.println("Area = " + area);
		System.out.println("Perimeter = " + perimeter);
		
	}

}
