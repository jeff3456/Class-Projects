
/* Author: Jefferson Lee
 * Date: 01/29/2014
 * Section: CS101, Section 03, Spring 2014
 */
public class Assignment01a {
	public static void main(String[] args)
	{
		System.out.println("Welcome to Java!");
		System.out.println("...");
		System.out.println("That's all folks!");
	}
}
